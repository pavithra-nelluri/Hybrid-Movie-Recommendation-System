# Implementation

1) This application provides all the details of the requested movie such as overview, genre, release date, rating, runtime, top cast,recommended movies etc.

2) The details of the movies(title, genre, runtime, rating, poster, etc) are fetched using an API by TMDB, and using the IMDB id of the movie in the API.

3) You have to include your API key in both preprocessing 2 and preprocessing 3 files and in two places(mentioned in code) in static/recommend.js file. 

4) install all the requirements using the command
   pip install -r requirements.txt

5) To run the application enter the following command in terminal/command prompt from project directory.
   python run.py

6) Go to your browser and type
   http://127.0.0.1:5000/ in the address bar.

Now, you can search for any movie You want in search bar, dont worry if it is not auto suggested.
